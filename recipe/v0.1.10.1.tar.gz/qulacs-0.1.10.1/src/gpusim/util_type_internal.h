#ifndef _UTIL_TYPE_INTERNAL_H_
#define _UTIL_TYPE_INTERNAL_H_

#include <cuComplex.h>
typedef cuDoubleComplex GTYPE;

#endif // #ifndef _UTIL_COMMON_CU_H_